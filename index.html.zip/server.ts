import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "5mb" }));

  // Initialize Gemini AI
  const ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  // API route for AI Analytics
  app.post("/api/ai/analyze", async (req, res) => {
    try {
      const { question, databaseState } = req.body;

      if (!question || typeof question !== "string") {
        return res.status(400).json({ error: "A valid question string is required." });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({
          error: "GEMINI_API_KEY environment variable is not configured.",
        });
      }

      const systemPrompt = `You are Dream Star MD Management System's official AI Analytics Assistant.
You have real-time access to the complete Firebase database state of the system provided below in JSON format.
Your goal is to answer questions about student registrations, batch performance, seller outputs, team/MD financial analytics, withdrawals, and course fee collections accurately.

DATABASE STATE SUMMARY:
${JSON.stringify(databaseState, null, 2)}

INSTRUCTIONS:
1. Answer accurately based ONLY on the provided live database state.
2. If asked in Bengali (Bangla) or Bangla-English script, reply in Bengali with clear formatting (bold numbers, lists, bullet points). If asked in English, reply in English.
3. Include specific numbers (BDT amounts, student counts, seller totals) whenever applicable.
4. Keep answers friendly, professional, structured, and easy to read.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `${systemPrompt}\n\nUSER QUESTION: ${question}` }],
          },
        ],
      });

      const answerText = response.text || "No response generated from AI.";
      return res.json({ answer: answerText });
    } catch (err: any) {
      console.error("Error in AI analysis endpoint:", err);
      return res.status(500).json({ error: err.message || "Internal server error" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
