import { initializeApp } from "firebase/app";
import { getDatabase, ref, push, set, get, child, remove, onValue } from "firebase/database";

const firebaseConfig = {
    apiKey: "AIzaSyCnuoso4FuwFSl0KLw1EXWgU-Lsx21GSso",
    authDomain: "jihad-28dbc.firebaseapp.com",
    projectId: "jihad-28dbc",
    storageBucket: "jihad-28dbc.firebasestorage.app",
    messagingSenderId: "162050220457",
    appId: "1:162050220457:web:ac9a2c46cc576cef5e24b8",
    measurementId: "G-25Z77NP8DF",
    databaseURL: "https://jihad-28dbc-default-rtdb.asia-southeast1.firebasedatabase.app/"
};

const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);
export { ref, push, set, get, child, remove, onValue };
