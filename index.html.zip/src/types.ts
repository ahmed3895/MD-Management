export interface Team {
  name: string;
  password: string;
  mdName: string;
  mdImage: string;
}

export interface Student {
  teamName: string;
  studentName: string;
  studentId: string;
  sellerId: string;
  batchNumber: string;
  paymentType: 'Full Payment' | 'Booking';
  bookingAmount?: number;
  timestamp: number;
}

export interface WithdrawalItem {
  sellerId: string;
  amount: number;
}

export interface Withdrawal {
  teamName: string;
  items: WithdrawalItem[];
  totalWithdrawn: number;
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
}
