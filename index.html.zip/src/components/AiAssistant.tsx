import React, { useState, useRef, useEffect } from "react";
import { Sparkles, Send, Bot, User, ChevronUp, ChevronDown, RefreshCw, BarChart2, Trophy, GraduationCap, DollarSign, Users, Key, Settings } from "lucide-react";
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from "../types";

interface AiAssistantProps {
  databaseState: {
    teams: Record<string, any>;
    batches: Record<string, any>;
    courseFee: number;
    students: Record<string, any>;
    withdrawals: Record<string, any>;
    metrics: {
      totalStudents: number;
      grandTotalSales: number;
      fullPaymentTotal: number;
      bookingTotal: number;
      totalWithdrawn: number;
    };
  };
}

export const AiAssistant: React.FC<AiAssistantProps> = ({ databaseState }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [showKeyInput, setShowKeyInput] = useState(false);
  const [customApiKey, setCustomApiKey] = useState(() => localStorage.getItem("ds_gemini_key") || "");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome-msg",
      sender: "ai",
      text: "👋 Assalamu Alaikum! I am **Dream Star AI Analyst**. Ask me anything about squad sales, student counts, seller outputs, batch performance, or financial withdrawals!",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputQuestion, setInputQuestion] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const saveApiKey = (key: string) => {
    setCustomApiKey(key);
    localStorage.setItem("ds_gemini_key", key);
  };

  const handleSendQuestion = async (textToSend?: string) => {
    const q = (textToSend || inputQuestion).trim();
    if (!q || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: "user",
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputQuestion("");
    setIsLoading(true);

    let answer = "";

    try {
      // 1. First attempt: Express backend or Netlify Function endpoint
      const response = await fetch("/api/ai/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: q,
          databaseState: databaseState
        })
      });

      const contentType = response.headers.get("content-type") || "";

      if (response.ok && contentType.includes("application/json")) {
        const data = await response.json();
        if (data.answer) {
          answer = data.answer;
        } else {
          throw new Error(data.error || "NO_BACKEND_ANSWER");
        }
      } else {
        // Static hosting fallback (e.g. Netlify serving index.html or 404)
        throw new Error("STATIC_HOSTING_FALLBACK");
      }
    } catch (err: any) {
      // 2. Client-side fallback for static platforms like Netlify
      try {
        const activeKey = customApiKey || (import.meta as any).env?.VITE_GEMINI_API_KEY || (typeof process !== "undefined" ? process.env.GEMINI_API_KEY : "") || "AQ.Ab8RN6LY2y2yC8fQn6AKr3501TdmXG2K0jFqsZNFXqL-fcgtkQ";
        if (activeKey) {
          const ai = new GoogleGenAI({ apiKey: activeKey });
          const systemPrompt = `You are Dream Star MD Management System's official AI Analytics Assistant.
You have real-time access to the complete Firebase database state of the system provided below in JSON format.
Your goal is to answer questions about student registrations, batch performance, seller outputs, team/MD financial analytics, withdrawals, and course fee collections accurately.

DATABASE STATE SUMMARY:
${JSON.stringify(databaseState, null, 2)}

INSTRUCTIONS:
1. Answer accurately based ONLY on the provided live database state.
2. If asked in Bengali (Bangla) or Bangla-English script (e.g., "koto taka", "koto jon student", "top squad kon ta"), reply in Bengali with clear formatting (bold numbers, lists, bullet points). If asked in English, reply in English.
3. Include specific numbers (BDT amounts, student counts, seller totals) whenever applicable.
4. Keep answers friendly, professional, structured, and easy to read.`;

          let clientRes;
          try {
            clientRes = await ai.models.generateContent({
              model: "gemini-2.5-flash",
              contents: [
                {
                  role: "user",
                  parts: [{ text: `${systemPrompt}\n\nUSER QUESTION: ${q}` }],
                },
              ],
            });
          } catch (m1Err) {
            clientRes = await ai.models.generateContent({
              model: "gemini-1.5-flash",
              contents: [
                {
                  role: "user",
                  parts: [{ text: `${systemPrompt}\n\nUSER QUESTION: ${q}` }],
                },
              ],
            });
          }

          answer = clientRes.text || "No response generated.";
        } else {
          // 3. Smart dynamic offline analysis fallback if no API key is present on Netlify
          answer = performLocalAnalytics(q, databaseState);
        }
      } catch (clientErr: any) {
        console.error("Client Gemini Error:", clientErr);
        answer = performLocalAnalytics(q, databaseState);
      }
    }

    const aiMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      sender: "ai",
      text: answer,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, aiMsg]);
    setIsLoading(false);
  };

  const performLocalAnalytics = (q: string, state: typeof databaseState): string => {
    const qLower = q.toLowerCase();
    const isBengali = /[\u0980-\u09FF]/.test(q) || qLower.includes("bengali") || qLower.includes("bangla") || qLower.includes("koto") || qLower.includes("taka") || qLower.includes("jon") || qLower.includes("kon");
    const m = state.metrics;
    const studentList = Object.values(state.students || {});
    const squadList = Object.values(state.teams || {});
    const withdrawalList = Object.values(state.withdrawals || {});
    const batchList = Object.values(state.batches || {});

    // Squad stats computation
    const squadStats: Record<string, { mdName: string; count: number; fullPayCount: number; bookingCount: number; revenue: number; withdrawn: number }> = {};
    squadList.forEach((t: any) => {
      squadStats[t.name] = { mdName: t.mdName || "MD", count: 0, fullPayCount: 0, bookingCount: 0, revenue: 0, withdrawn: 0 };
    });

    studentList.forEach((s: any) => {
      const amt = s.paymentType === 'Booking' ? (Number(s.bookingAmount) || 0) : state.courseFee;
      if (!squadStats[s.teamName]) {
        squadStats[s.teamName] = { mdName: "MD", count: 0, fullPayCount: 0, bookingCount: 0, revenue: 0, withdrawn: 0 };
      }
      squadStats[s.teamName].count += 1;
      if (s.paymentType === 'Booking') {
        squadStats[s.teamName].bookingCount += 1;
      } else {
        squadStats[s.teamName].fullPayCount += 1;
      }
      squadStats[s.teamName].revenue += amt;
    });

    withdrawalList.forEach((w: any) => {
      if (squadStats[w.teamName]) {
        squadStats[w.teamName].withdrawn += Number(w.totalWithdrawn) || 0;
      }
    });

    // Batch stats
    const batchStats: Record<string, { count: number; revenue: number }> = {};
    batchList.forEach((b: any) => {
      batchStats[b] = { count: 0, revenue: 0 };
    });
    studentList.forEach((s: any) => {
      const bName = s.batchNumber || "Unassigned";
      const amt = s.paymentType === 'Booking' ? (Number(s.bookingAmount) || 0) : state.courseFee;
      if (!batchStats[bName]) batchStats[bName] = { count: 0, revenue: 0 };
      batchStats[bName].count += 1;
      batchStats[bName].revenue += amt;
    });

    // Identify top squad
    let topSquad = "";
    let topRev = -1;
    Object.keys(squadStats).forEach(sName => {
      if (squadStats[sName].revenue > topRev) {
        topRev = squadStats[sName].revenue;
        topSquad = sName;
      }
    });

    const keyAdviceBengali = "";
    const keyAdviceEnglish = "";

    // Intent routing
    if (qLower.includes("student") || qLower.includes("ছাত্র") || qLower.includes("জন") || qLower.includes("কতো") || qLower.includes("সংখ্যা")) {
      if (isBengali) {
        let details = `👥 **শিক্ষার্থী সংখ্যা ও রেজিস্ট্রেশন রিপোর্ট:**\n\n`;
        details += `• **সর্বমোট স্টুডেন্ট:** ${m.totalStudents} জন\n`;
        details += `• **ফুল পেমেন্ট স্টুডেন্ট:** ${studentList.filter((s: any) => s.paymentType !== 'Booking').length} জন\n`;
        details += `• **বুকিং স্টুডেন্ট:** ${studentList.filter((s: any) => s.paymentType === 'Booking').length} জন\n\n`;
        details += `📋 **স্কোয়াড ভিত্তিক স্টুডেন্ট সংখ্যা:**\n`;
        Object.entries(squadStats).forEach(([sName, data]) => {
          details += `• **${sName}** (${data.mdName}): ${data.count} জন (ফুল: ${data.fullPayCount}, বুকিং: ${data.bookingCount})\n`;
        });
        return details + keyAdviceBengali;
      } else {
        let details = `👥 **Student Count & Registration Analytics:**\n\n`;
        details += `• **Total Registered Students:** ${m.totalStudents}\n`;
        details += `• **Full Payment Students:** ${studentList.filter((s: any) => s.paymentType !== 'Booking').length}\n`;
        details += `• **Booking Students:** ${studentList.filter((s: any) => s.paymentType === 'Booking').length}\n\n`;
        details += `📋 **Squad Breakdown:**\n`;
        Object.entries(squadStats).forEach(([sName, data]) => {
          details += `• **${sName}** (${data.mdName}): ${data.count} students (Full: ${data.fullPayCount}, Booking: ${data.bookingCount})\n`;
        });
        return details + keyAdviceEnglish;
      }
    }

    if (qLower.includes("batch") || qLower.includes("ব্যাচ")) {
      if (isBengali) {
        let details = `🎓 **ব্যাচ ভিত্তিক পারফরম্যান্স সামারি:**\n\n`;
        Object.entries(batchStats).forEach(([bName, data]) => {
          details += `• **${bName}:** ${data.count} জন স্টুডেন্ট | কালেকশন: **${data.revenue} BDT**\n`;
        });
        return details + keyAdviceBengali;
      } else {
        let details = `🎓 **Batch Performance Breakdown:**\n\n`;
        Object.entries(batchStats).forEach(([bName, data]) => {
          details += `• **${bName}:** ${data.count} Students | Revenue: **${data.revenue} BDT**\n`;
        });
        return details + keyAdviceEnglish;
      }
    }

    if (qLower.includes("withdraw") || qLower.includes("ক্যাশ") || qLower.includes("তুল") || qLower.includes("উইথড্র")) {
      if (isBengali) {
        let details = `💸 **স্কোয়াড ক্যাশ উইথড্রয়াল সামারি:**\n\n`;
        details += `• **মোট উত্তোলিত অর্থ:** **${m.totalWithdrawn} BDT**\n\n`;
        Object.entries(squadStats).forEach(([sName, data]) => {
          const net = data.revenue - data.withdrawn;
          details += `• **${sName}:** মোট সেলস: ${data.revenue} BDT | উইথড্র: **${data.withdrawn} BDT** | নেট ব্যালেন্স: **${net} BDT**\n`;
        });
        return details + keyAdviceBengali;
      } else {
        let details = `💸 **Squad Cash Withdrawal Summary:**\n\n`;
        details += `• **Total Cash Withdrawn:** **${m.totalWithdrawn} BDT**\n\n`;
        Object.entries(squadStats).forEach(([sName, data]) => {
          const net = data.revenue - data.withdrawn;
          details += `• **${sName}:** Sales: ${data.revenue} BDT | Withdrawn: **${data.withdrawn} BDT** | Net Balance: **${net} BDT**\n`;
        });
        return details + keyAdviceEnglish;
      }
    }

    if (qLower.includes("top") || qLower.includes("squad") || qLower.includes("স্কোয়াড") || qLower.includes("সেরা") || qLower.includes("best")) {
      if (isBengali) {
        let details = `🏆 **স্কোয়াড র্যাংকিং ও পারফরম্যান্স বিশ্লেষণ:**\n\n`;
        if (topSquad) {
          details += `⭐ **১ম স্থান (Top Squad):** **${topSquad}** (${squadStats[topSquad]?.mdName}) - **${topRev} BDT** কালেকশন (${squadStats[topSquad]?.count} জন স্টুডেন্ট)\n\n`;
        }
        details += `📊 **সকল স্কোয়াড লিস্ট:**\n`;
        Object.entries(squadStats)
          .sort((a, b) => b[1].revenue - a[1].revenue)
          .forEach(([sName, data], idx) => {
            details += `${idx + 1}. **${sName}** (${data.mdName}) - **${data.revenue} BDT** (স্টুডেন্ট: ${data.count} জন)\n`;
          });
        return details + keyAdviceBengali;
      } else {
        let details = `🏆 **Squad Rankings & Performance Analytics:**\n\n`;
        if (topSquad) {
          details += `⭐ **Rank #1:** **${topSquad}** (${squadStats[topSquad]?.mdName}) - **${topRev} BDT** (${squadStats[topSquad]?.count} students)\n\n`;
        }
        details += `📊 **All Squads Leaderboard:**\n`;
        Object.entries(squadStats)
          .sort((a, b) => b[1].revenue - a[1].revenue)
          .forEach(([sName, data], idx) => {
            details += `${idx + 1}. **${sName}** (${data.mdName}) - **${data.revenue} BDT** (${data.count} students)\n`;
          });
        return details + keyAdviceEnglish;
      }
    }

    // Default overview
    if (isBengali) {
      return `📊 **লাইভ ডাটাবেজ সামারি (Netlify System):**\n\n` +
        `• **মোট স্টুডেন্ট:** ${m.totalStudents} জন\n` +
        `• **মোট কালেকশন:** **${m.grandTotalSales} BDT** (ফুল: ${m.fullPaymentTotal} | বুকিং: ${m.bookingTotal})\n` +
        `• **মোট উইথড্রয়াল:** **${m.totalWithdrawn} BDT**\n` +
        (topSquad ? `• **সেরা স্কোয়াড:** **${topSquad}** (${topRev} BDT)\n` : "") +
        keyAdviceBengali;
    } else {
      return `📊 **Live Database Summary (Netlify Host):**\n\n` +
        `• **Total Students:** ${m.totalStudents}\n` +
        `• **Total Revenue:** **${m.grandTotalSales} BDT** (Full: ${m.fullPaymentTotal} | Booking: ${m.bookingTotal})\n` +
        `• **Total Withdrawn:** **${m.totalWithdrawn} BDT**\n` +
        (topSquad ? `• **Top Squad:** **${topSquad}** (${topRev} BDT)\n` : "") +
        keyAdviceEnglish;
    }
  };

  const quickPrompts = [
    { label: "Total Revenue & Sales", prompt: "Summarize the total system sales revenue and breakdown by Full Payment vs Bookings.", icon: DollarSign },
    { label: "Top Squad Performance", prompt: "Which squad has generated the highest sales revenue and how many students do they have?", icon: Trophy },
    { label: "Batch Wise Summary", prompt: "Give me a batch wise breakdown of students and revenue collected.", icon: GraduationCap },
    { label: "Cash Withdrawal Stats", prompt: "Provide a detailed summary of all squad cash withdrawals and net balances.", icon: BarChart2 },
    { label: "Total Students Count", prompt: "How many total students are registered across all squads and batches?", icon: Users },
  ];

  return (
    <div className="fixed bottom-0 inset-x-0 z-50 px-3 sm:px-6 pb-2 pointer-events-none">
      <div className="max-w-4xl mx-auto pointer-events-auto bg-white border border-indigo-200/80 rounded-2xl shadow-2xl shadow-indigo-900/15 overflow-hidden transition-all duration-300">
        
        {/* Assistant Header Toggle */}
        <div 
          className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 px-4 py-3 text-white flex items-center justify-between cursor-pointer hover:opacity-95 transition-all select-none"
        >
          <div onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-2.5 flex-grow">
            <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center border border-amber-300/30 animate-pulse">
              <Sparkles className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm sm:text-base tracking-tight text-white">
                  DREAM STAR AI ANALYST
                </h3>
                <span className="px-2 py-0.5 bg-indigo-500/30 text-indigo-200 text-[10px] font-bold uppercase rounded-full border border-indigo-400/30">
                  Live Firebase Connected
                </span>
              </div>
              <p className="text-[11px] text-indigo-200/80 font-medium hidden sm:block">
                Ask any question in Bengali or English to analyze realtime system data
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button 
              onClick={(e) => {
                e.stopPropagation();
                setShowKeyInput(!showKeyInput);
                if (!isOpen) setIsOpen(true);
              }}
              title="Gemini API Key Settings for Netlify"
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-amber-300 transition-all text-xs flex items-center gap-1"
            >
              <Key className="w-4 h-4" />
            </button>

            <button 
              onClick={() => setIsOpen(!isOpen)}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-all text-xs"
            >
              {isOpen ? <ChevronDown className="w-5 h-5" /> : <ChevronUp className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* API Key Settings Drawer for Netlify */}
        {isOpen && showKeyInput && (
          <div className="bg-slate-900 border-b border-indigo-800/50 p-3 text-white text-xs flex flex-col sm:flex-row items-center gap-2">
            <div className="flex items-center gap-1.5 text-amber-300 font-bold shrink-0">
              <Key className="w-4 h-4" />
              <span>Netlify Gemini API Key:</span>
            </div>
            <input
              type="password"
              value={customApiKey}
              onChange={(e) => saveApiKey(e.target.value)}
              placeholder="Paste GEMINI_API_KEY for Netlify (AIzaSy...)"
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-400 flex-grow w-full sm:w-auto"
            />
            <button
              onClick={() => setShowKeyInput(false)}
              className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 font-bold text-xs rounded-lg transition-all"
            >
              Save Key
            </button>
          </div>
        )}

        {/* Expandable Chat Container */}
        {isOpen && (
          <div className="flex flex-col h-[380px] sm:h-[440px] bg-slate-50/60">
            
            {/* Quick Prompts Bar */}
            <div className="bg-white px-3 py-2 border-b border-slate-200/60 overflow-x-auto flex items-center gap-2 text-xs no-scrollbar">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider whitespace-nowrap">Quick Queries:</span>
              {quickPrompts.map((qp, idx) => {
                const Icon = qp.icon;
                return (
                  <button
                    key={idx}
                    onClick={() => handleSendQuestion(qp.prompt)}
                    disabled={isLoading}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-semibold rounded-lg border border-indigo-100 transition-all whitespace-nowrap flex items-center gap-1 text-[11px] disabled:opacity-50"
                  >
                    <Icon className="w-3 h-3 text-indigo-600" />
                    {qp.label}
                  </button>
                );
              })}
            </div>

            {/* Message History */}
            <div className="flex-grow p-4 overflow-y-auto space-y-3.5 text-xs sm:text-sm">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-2.5 ${
                    msg.sender === "user" ? "flex-row-reverse" : "flex-row"
                  }`}
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-xs font-bold ${
                      msg.sender === "user"
                        ? "bg-slate-800 text-white"
                        : "bg-indigo-600 text-white shadow-sm"
                    }`}
                  >
                    {msg.sender === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 border shadow-xs ${
                      msg.sender === "user"
                        ? "bg-slate-900 text-white border-slate-800 rounded-tr-xs"
                        : "bg-white text-slate-800 border-slate-200/80 rounded-tl-xs"
                    }`}
                  >
                    <div className="whitespace-pre-wrap leading-relaxed font-normal">
                      {msg.text}
                    </div>
                    <div
                      className={`text-[10px] mt-1.5 text-right font-medium ${
                        msg.sender === "user" ? "text-slate-400" : "text-slate-400"
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                    <Bot className="w-4 h-4 animate-spin" />
                  </div>
                  <div className="bg-white border border-slate-200 rounded-2xl p-3 text-slate-500 text-xs flex items-center gap-2">
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                    <span>Analyzing Firebase dataset with Gemini AI...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendQuestion();
              }}
              className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2"
            >
              <input
                type="text"
                value={inputQuestion}
                onChange={(e) => setInputQuestion(e.target.value)}
                placeholder="Ask AI about student numbers, squad revenue, top sellers, or withdrawals..."
                disabled={isLoading}
                className="flex-grow bg-slate-50 border border-slate-200 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-800 focus:outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-600/10 placeholder-slate-400 transition-all"
              />
              <button
                type="submit"
                disabled={isLoading || !inputQuestion.trim()}
                className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold px-4 py-2.5 rounded-xl shadow-md text-xs sm:text-sm transition-all flex items-center gap-1.5 shrink-0"
              >
                <Send className="w-4 h-4" />
                <span className="hidden sm:inline">Ask AI</span>
              </button>
            </form>

          </div>
        )}

      </div>
    </div>
  );
};
