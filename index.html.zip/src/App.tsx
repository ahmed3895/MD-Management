import React, { useState, useEffect, useRef } from "react";
import html2canvas from "html2canvas";
import { db, ref, push, set, remove, onValue } from "./lib/firebase";
import { Team, Student, Withdrawal, WithdrawalItem } from "./types";
import { AiAssistant } from "./components/AiAssistant";

const DB_STUDENTS_REF = "students";
const DB_SETTINGS_REF = "settings";
const DB_WITHDRAWALS_REF = "withdrawals";

const DEFAULT_TEAMS_CONFIG: Record<string, Team> = {
  squad1: {
    name: "Dream Squad",
    password: "pakhi123",
    mdName: "Sanzida Rahman Pakhi",
    mdImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400",
  },
  squad2: {
    name: "Success Squad",
    password: "bangladesh",
    mdName: "Tahsan Khan",
    mdImage: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400",
  },
  squad3: {
    name: "Champion Squad",
    password: "shanjida123",
    mdName: "Shanjida Islam",
    mdImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400",
  },
  squad4: {
    name: "Victory Squad",
    password: "taifa123",
    mdName: "Taifa Yeasmin",
    mdImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400",
  },
};

const DEFAULT_BATCHES_CONFIG: Record<string, string> = {
  batch01: "Batch 01",
  batch02: "Batch 02",
  batch03: "Batch 03",
  batch04: "Batch 04",
};

export default function App() {
  // Navigation State
  const [activePortal, setActivePortal] = useState<"student-portal" | "admin-portal">("student-portal");
  const [activeStudentTab, setActiveStudentTab] = useState<"home" | "register" | "database">("home");
  const [activeAdminTab, setActiveAdminTab] = useState<"team-config" | "batch-config" | "master-db" | "financial-insights">("team-config");

  // Admin Auth Modal State
  const [isAdminAuthModalOpen, setIsAdminAuthModalOpen] = useState(false);
  const [adminAuthPasswordInput, setAdminAuthPasswordInput] = useState("");
  const [adminAuthError, setAdminAuthError] = useState("");

  // Firebase Realtime State
  const [teams, setTeams] = useState<Record<string, Team>>({});
  const [batches, setBatches] = useState<Record<string, string>>({});
  const [courseFee, setCourseFee] = useState<number>(4000);
  const [students, setStudents] = useState<Record<string, Student>>({});
  const [withdrawals, setWithdrawals] = useState<Record<string, Withdrawal>>({});

  // Squad Unlock State
  const [activeUnlockedSquad, setActiveUnlockedSquad] = useState<string | null>(null);
  const [squadPasswordInput, setSquadPasswordInput] = useState("");
  const [squadPassError, setSquadPassError] = useState(false);

  // Student Form State
  const [studentEditKey, setStudentEditKey] = useState("");
  const [regPaymentType, setRegPaymentType] = useState<"Full Payment" | "Booking">("Full Payment");
  const [regTeamSelect, setRegTeamSelect] = useState("");
  const [regSellerId, setRegSellerId] = useState("");
  const [regBatchSelect, setRegBatchSelect] = useState("");
  const [regStudentName, setRegStudentName] = useState("");
  const [regStudentId, setRegStudentId] = useState("");
  const [regBookingAmount, setRegBookingAmount] = useState("");

  // Admin Config Form State
  const [editTeamKey, setEditTeamKey] = useState("");
  const [adminTeamName, setAdminTeamName] = useState("");
  const [adminTeamPassword, setAdminTeamPassword] = useState("");
  const [adminTeamMdName, setAdminTeamMdName] = useState("");
  const [adminTeamMdImage, setAdminTeamMdImage] = useState("");
  const [adminBatchInput, setAdminBatchInput] = useState("");

  // Master Filters State
  const [filterType, setFilterType] = useState("all");
  const [filterTeam, setFilterTeam] = useState("all");
  const [filterBatch, setFilterBatch] = useState("all");

  // Invoice Modal State
  const [isInvoiceModalOpen, setIsInvoiceModalOpen] = useState(false);
  const [invoiceTeamSelect, setInvoiceTeamSelect] = useState("");
  const [invoiceRows, setInvoiceRows] = useState<{ id: string; sellerId: string; amount: string }[]>([
    { id: "inv-row-1", sellerId: "", amount: "" }
  ]);

  // Receipt Modal State
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [receiptData, setReceiptData] = useState<{
    id: string;
    date: string;
    team: string;
    gross: number;
    items: WithdrawalItem[];
  } | null>(null);
  const receiptCaptureRef = useRef<HTMLDivElement>(null);

  // Success Modal State
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [successDetails, setSuccessDetails] = useState<{
    studentName: string;
    teamName: string;
    mdName: string;
    type: string;
  } | null>(null);

  // Firebase Subscriptions
  useEffect(() => {
    const settingsRef = ref(db, DB_SETTINGS_REF);
    const unsubscribeSettings = onValue(settingsRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.val();
        setTeams(data.teams || {});
        setBatches(data.batches || {});
        setCourseFee(Number(data.courseFee) || 4000);
      } else {
        set(ref(db, DB_SETTINGS_REF), {
          teams: DEFAULT_TEAMS_CONFIG,
          batches: DEFAULT_BATCHES_CONFIG,
          courseFee: 4000,
        });
        setTeams(DEFAULT_TEAMS_CONFIG);
        setBatches(DEFAULT_BATCHES_CONFIG);
        setCourseFee(4000);
      }
    });

    const studentsRef = ref(db, DB_STUDENTS_REF);
    const unsubscribeStudents = onValue(studentsRef, (snapshot) => {
      setStudents(snapshot.exists() ? snapshot.val() : {});
    });

    const withdrawalsRef = ref(db, DB_WITHDRAWALS_REF);
    const unsubscribeWithdrawals = onValue(withdrawalsRef, (snapshot) => {
      setWithdrawals(snapshot.exists() ? snapshot.val() : {});
    });

    return () => {
      unsubscribeSettings();
      unsubscribeStudents();
      unsubscribeWithdrawals();
    };
  }, []);

  // Handlers & Functions
  const handleSwitchPortal = (portalId: "student-portal" | "admin-portal") => {
    if (portalId === "admin-portal") {
      if (activePortal === "admin-portal") {
        return;
      }
      setAdminAuthPasswordInput("");
      setAdminAuthError("");
      setIsAdminAuthModalOpen(true);
      return;
    }
    setActivePortal("student-portal");
    setActiveStudentTab("home");
  };

  const submitAdminAuth = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (adminAuthPasswordInput.trim() === "admin123") {
      setIsAdminAuthModalOpen(false);
      setAdminAuthError("");
      setAdminAuthPasswordInput("");
      setActivePortal("admin-portal");
      setActiveAdminTab("team-config");
    } else {
      setAdminAuthError("⛔ Unauthorized Access! Invalid Admin Password.");
    }
  };

  const viewTeamBreakdownDirectly = (teamName: string) => {
    setActiveStudentTab("database");
    const matchedTeam = (Object.values(teams) as Team[]).find((t) => t.name === teamName);
    if (matchedTeam) {
      setSquadPasswordInput(matchedTeam.password);
    }
  };

  const unlockSquadDatabase = () => {
    const passwordAttempt = squadPasswordInput.trim();
    let verifiedSquadName: string | null = null;

    for (const details of (Object.values(teams) as Team[])) {
      if (details.password === passwordAttempt) {
        verifiedSquadName = details.name;
        break;
      }
    }

    if (verifiedSquadName) {
      setSquadPassError(false);
      setSquadPasswordInput("");
      setActiveUnlockedSquad(verifiedSquadName);
    } else {
      setSquadPassError(true);
    }
  };

  const lockSquadDatabase = () => {
    setActiveUnlockedSquad(null);
  };

  const updateGlobalCourseFee = async (val: string) => {
    const fee = Number(val) || 0;
    try {
      await set(ref(db, `${DB_SETTINGS_REF}/courseFee`), fee);
      setCourseFee(fee);
    } catch (e: any) {
      alert("Error updating course fee: " + e.message);
    }
  };

  const handleRegistration = async (e: React.FormEvent) => {
    e.preventDefault();

    const record: Student = {
      teamName: regTeamSelect,
      studentName: regStudentName,
      studentId: regStudentId,
      sellerId: regSellerId,
      batchNumber: regBatchSelect,
      paymentType: regPaymentType,
      bookingAmount: regPaymentType === "Booking" ? Number(regBookingAmount) || 0 : 0,
      timestamp: new Date().getTime(),
    };

    try {
      if (studentEditKey !== "") {
        await set(ref(db, `${DB_STUDENTS_REF}/${studentEditKey}`), record);
        alert("✓ Record has been updated!");
      } else {
        await push(ref(db, DB_STUDENTS_REF), record);
        showRegistrationSuccessModal(regStudentName, regTeamSelect, regPaymentType);
      }
      resetRegForm();
    } catch (err: any) {
      alert("❌ Save error: " + err.message);
    }
  };

  const showRegistrationSuccessModal = (sName: string, tName: string, type: string) => {
    const matchingTeamData = (Object.values(teams) as Team[]).find((t) => t.name === tName);
    const mdName = matchingTeamData ? matchingTeamData.mdName : "Squad MD";

    setSuccessDetails({
      studentName: sName,
      teamName: tName,
      mdName: mdName,
      type: type,
    });
    setIsSuccessModalOpen(true);
  };

  const resetRegForm = () => {
    setStudentEditKey("");
    setRegTeamSelect("");
    setRegStudentName("");
    setRegStudentId("");
    setRegSellerId("");
    setRegBatchSelect("");
    setRegPaymentType("Full Payment");
    setRegBookingAmount("");
  };

  const editStudentRecord = (key: string) => {
    const data = students[key];
    if (!data) return;

    setActiveStudentTab("register");
    setStudentEditKey(key);
    setRegTeamSelect(data.teamName);
    setRegStudentName(data.studentName);
    setRegStudentId(data.studentId);
    setRegSellerId(data.sellerId);
    setRegBatchSelect(data.batchNumber);
    setRegPaymentType(data.paymentType || "Full Payment");
    if (data.paymentType === "Booking") {
      setRegBookingAmount(String(data.bookingAmount || 0));
    }
  };

  const deleteStudentRecord = async (key: string) => {
    if (confirm("Are you sure you want to delete this profile?")) {
      try {
        await remove(ref(db, `${DB_STUDENTS_REF}/${key}`));
      } catch (err: any) {
        alert("Delete failed: " + err.message);
      }
    }
  };

  const convertToFullPayment = async (studentKey: string) => {
    const student = students[studentKey];
    if (!student) return;

    if (confirm(`Upgrade ${student.studentName} to Full Payment?`)) {
      try {
        await set(ref(db, `${DB_STUDENTS_REF}/${studentKey}/paymentType`), "Full Payment");
        await set(ref(db, `${DB_STUDENTS_REF}/${studentKey}/bookingAmount`), 0);
        showRegistrationSuccessModal(student.studentName, student.teamName, "Full Payment");
      } catch (e: any) {
        alert("Conversion failed: " + e.message);
      }
    }
  };

  const handleTeamConfigSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const configObject: Team = {
      name: adminTeamName.trim(),
      password: adminTeamPassword.trim(),
      mdName: adminTeamMdName.trim(),
      mdImage: adminTeamMdImage.trim(),
    };

    try {
      if (editTeamKey !== "") {
        await set(ref(db, `${DB_SETTINGS_REF}/teams/${editTeamKey}`), configObject);
      } else {
        const newTeamRef = push(ref(db, `${DB_SETTINGS_REF}/teams`));
        await set(newTeamRef, configObject);
      }
      resetAdminTeamForm();
    } catch (err: any) {
      alert("Squad Config failed: " + err.message);
    }
  };

  const editTeamConfig = (key: string) => {
    const team = teams[key];
    if (!team) return;
    setEditTeamKey(key);
    setAdminTeamName(team.name);
    setAdminTeamPassword(team.password);
    setAdminTeamMdName(team.mdName);
    setAdminTeamMdImage(team.mdImage);
  };

  const deleteTeamConfig = async (key: string) => {
    if (confirm("Delete this squad?")) {
      try {
        await remove(ref(db, `${DB_SETTINGS_REF}/teams/${key}`));
      } catch (err: any) {
        alert("Failed: " + err.message);
      }
    }
  };

  const resetAdminTeamForm = () => {
    setEditTeamKey("");
    setAdminTeamName("");
    setAdminTeamPassword("");
    setAdminTeamMdName("");
    setAdminTeamMdImage("");
  };

  const addBatchConfig = async () => {
    const batchVal = adminBatchInput.trim();
    if (batchVal === "") return;
    try {
      const newBatchRef = push(ref(db, `${DB_SETTINGS_REF}/batches`));
      await set(newBatchRef, batchVal);
      setAdminBatchInput("");
    } catch (err: any) {
      alert("Failed: " + err.message);
    }
  };

  const deleteBatchConfig = async (key: string) => {
    if (confirm("Delete batch option?")) {
      try {
        await remove(ref(db, `${DB_SETTINGS_REF}/batches/${key}`));
      } catch (err: any) {
        alert("Error: " + err.message);
      }
    }
  };

  const resetTeamWithdrawals = async (teamName: string) => {
    if (
      confirm(
        `Are you sure you want to reset the withdrawn amount for "${teamName}" back to 0 BDT? This will permanently wipe its withdrawal transaction history records.`
      )
    ) {
      try {
        const deletePromises: Promise<void>[] = [];
        Object.keys(withdrawals).forEach((key) => {
          if (withdrawals[key].teamName === teamName) {
            deletePromises.push(remove(ref(db, `${DB_WITHDRAWALS_REF}/${key}`)));
          }
        });

        if (deletePromises.length > 0) {
          await Promise.all(deletePromises);
          alert(`✓ Withdrawn amount for "${teamName}" has been successfully reset to 0 BDT!`);
        } else {
          alert("No existing withdrawal records found for this squad.");
        }
      } catch (e: any) {
        alert("Reset execution failed: " + e.message);
      }
    }
  };

  // Invoice Handlers
  const addInvoiceItemRow = () => {
    setInvoiceRows((prev) => [
      ...prev,
      { id: `inv-row-${Date.now()}-${Math.floor(Math.random() * 100)}`, sellerId: "", amount: "" },
    ]);
  };

  const removeInvoiceItemRow = (id: string) => {
    setInvoiceRows((prev) => prev.filter((r) => r.id !== id));
  };

  const calculateInvoiceGross = () => {
    return invoiceRows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0);
  };

  const submitInvoiceBill = async () => {
    if (!invoiceTeamSelect) {
      alert("Please select a Team first!");
      return;
    }

    const records: WithdrawalItem[] = [];
    let isValid = true;
    let totalBillSum = 0;

    invoiceRows.forEach((row) => {
      const sId = row.sellerId.trim();
      const amt = Number(row.amount) || 0;

      if (!sId || amt <= 0) {
        isValid = false;
      } else {
        records.push({ sellerId: sId, amount: amt });
        totalBillSum += amt;
      }
    });

    if (!isValid || records.length === 0) {
      alert("Please fill out all Seller IDs and positive numeric Amounts manually.");
      return;
    }

    if (confirm(`Process withdrawal & generate statement for ${totalBillSum} BDT?`)) {
      try {
        const trackingObject: Withdrawal = {
          teamName: invoiceTeamSelect,
          items: records,
          totalWithdrawn: totalBillSum,
          timestamp: new Date().getTime(),
        };

        await push(ref(db, DB_WITHDRAWALS_REF), trackingObject);
        setIsInvoiceModalOpen(false);

        // Open Receipt Modal
        setReceiptData({
          id: `DS-${Math.floor(10000 + Math.random() * 90000)}-TRX`,
          date: new Date().toISOString().split("T")[0],
          team: invoiceTeamSelect,
          gross: totalBillSum,
          items: records,
        });
        setIsReceiptModalOpen(true);
      } catch (e: any) {
        alert("Error saving invoice payload: " + e.message);
      }
    }
  };

  const downloadReceiptAsPNG = () => {
    if (!receiptCaptureRef.current) return;

    html2canvas(receiptCaptureRef.current, {
      useCORS: true,
      scale: 3,
      backgroundColor: "#ffffff",
      logging: false,
    })
      .then((canvas) => {
        const captureURI = canvas.toDataURL("image/png");
        const downloadAnchor = document.createElement("a");
        downloadAnchor.download = `Voucher_Receipt_${Date.now()}.png`;
        downloadAnchor.href = captureURI;
        downloadAnchor.click();
      })
      .catch((err) => {
        alert("PNG capture render error encountered: " + err.message);
      });
  };

  // Computations
  let grandTotalSales = 0;
  let totalFullPaymentAmt = 0;
  let totalBookingAmt = 0;
  let totalWithdrawnSumOverall = 0;

  (Object.values(students) as Student[]).forEach((s) => {
    if (s.paymentType === "Booking") {
      const bAmt = Number(s.bookingAmount) || 0;
      totalBookingAmt += bAmt;
      grandTotalSales += bAmt;
    } else {
      totalFullPaymentAmt += courseFee;
      grandTotalSales += courseFee;
    }
  });

  (Object.values(withdrawals) as Withdrawal[]).forEach((w) => {
    totalWithdrawnSumOverall += Number(w.totalWithdrawn) || 0;
  });

  // Calculate unlocked squad dynamic sales & withdrawals
  let unlockedSquadSales = 0;
  let unlockedSquadWithdrawn = 0;
  if (activeUnlockedSquad) {
    (Object.values(students) as Student[]).forEach((s) => {
      if (s.teamName === activeUnlockedSquad) {
        if (s.paymentType === "Booking") {
          unlockedSquadSales += Number(s.bookingAmount) || 0;
        } else {
          unlockedSquadSales += courseFee;
        }
      }
    });

    (Object.values(withdrawals) as Withdrawal[]).forEach((w) => {
      if (w.teamName === activeUnlockedSquad) {
        unlockedSquadWithdrawn += Number(w.totalWithdrawn) || 0;
      }
    });
  }

  // Batch analytics matrix
  const batchAnalytics: Record<
    string,
    {
      totalRevenue: number;
      fullPaymentCount: number;
      bookingCount: number;
      bookingCollected: number;
      teamContributions: Record<string, number>;
    }
  > = {};

  (Object.values(batches) as string[]).forEach((bName) => {
    batchAnalytics[bName] = {
      totalRevenue: 0,
      fullPaymentCount: 0,
      bookingCount: 0,
      bookingCollected: 0,
      teamContributions: {},
    };
    (Object.values(teams) as Team[]).forEach((t) => {
      batchAnalytics[bName].teamContributions[t.name] = 0;
    });
  });

  (Object.values(students) as Student[]).forEach((s) => {
    let amt = 0;
    if (s.paymentType === "Booking") {
      amt = Number(s.bookingAmount) || 0;
    } else {
      amt = courseFee;
    }

    const bName = s.batchNumber;
    if (batchAnalytics[bName]) {
      batchAnalytics[bName].totalRevenue += amt;
      if (s.paymentType === "Booking") {
        batchAnalytics[bName].bookingCount++;
        batchAnalytics[bName].bookingCollected += amt;
      } else {
        batchAnalytics[bName].fullPaymentCount++;
      }

      if (batchAnalytics[bName].teamContributions[s.teamName] !== undefined) {
        batchAnalytics[bName].teamContributions[s.teamName] += amt;
      } else {
        batchAnalytics[bName].teamContributions[s.teamName] = amt;
      }
    }
  });

  // Master DB Filtered List
  const filteredMasterStudents = Object.keys(students).filter((key) => {
    const s = students[key];
    const matchType = filterType === "all" || s.paymentType === filterType;
    const matchTeam = filterTeam === "all" || s.teamName === filterTeam;
    const matchBatch = filterBatch === "all" || s.batchNumber === filterBatch;
    return matchType && matchTeam && matchBatch;
  });

  // Compiled database state for AI Assistant
  const databaseStateForAi = {
    teams,
    batches,
    courseFee,
    students,
    withdrawals,
    metrics: {
      totalStudents: Object.keys(students).length,
      grandTotalSales,
      fullPaymentTotal: totalFullPaymentAmt,
      bookingTotal: totalBookingAmt,
      totalWithdrawn: totalWithdrawnSumOverall,
    },
  };

  return (
    <div className="text-slate-800 flex flex-col min-h-screen bg-slate-50 font-sans pb-24">
      {/* TOP NAVIGATION BAR */}
      <header className="bg-white border-b border-slate-200/80 sticky top-0 z-40 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2.5 rounded-xl shadow-md shadow-indigo-600/15">
              <i className="fas fa-star text-amber-300 text-lg"></i>
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-extrabold tracking-tight text-slate-900">
                DREAM STAR MD
              </h1>
              <p className="text-xs font-semibold text-indigo-600 tracking-wider uppercase">
                Management System
              </p>
            </div>
          </div>

          {/* Global Portal Switcher */}
          <div className="bg-slate-100 p-1 rounded-xl flex gap-1 border border-slate-200">
            <button
              onClick={() => handleSwitchPortal("student-portal")}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                activePortal === "student-portal"
                  ? "bg-white text-slate-900 shadow-xs border border-slate-200/50"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <i className="fas fa-user-graduate mr-1.5 text-indigo-600"></i>
              Student Portal
            </button>
            <button
              onClick={() => handleSwitchPortal("admin-portal")}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                activePortal === "admin-portal"
                  ? "bg-white text-slate-900 shadow-xs border border-slate-200/50"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
              }`}
            >
              <i className="fas fa-user-shield mr-1.5 text-slate-500"></i>
              Admin Console
            </button>
          </div>
        </div>
      </header>

      {/* PORTAL 1: STUDENT PORTAL */}
      {activePortal === "student-portal" && (
        <div className="flex-grow flex flex-col">
          {/* Sub Navigation */}
          <div className="bg-white border-b border-slate-100 py-3 shadow-xs">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center sm:justify-start gap-3 items-center flex-wrap">
              <button
                onClick={() => setActiveStudentTab("home")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeStudentTab === "home"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-home mr-1.5 text-indigo-600"></i>
                Home (MDs)
              </button>
              <button
                onClick={() => setActiveStudentTab("register")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeStudentTab === "register"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-edit mr-1.5"></i>
                Student Registration
              </button>
              <button
                onClick={() => setActiveStudentTab("database")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeStudentTab === "database"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-database mr-1.5"></i>
                Squad Databases
              </button>

              {/* INVOICE BUTTON OPTION */}
              <button
                onClick={() => {
                  setInvoiceRows([{ id: "inv-row-1", sellerId: "", amount: "" }]);
                  setInvoiceTeamSelect("");
                  setIsInvoiceModalOpen(true);
                }}
                className="ml-auto px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-bold shadow-xs flex items-center gap-1.5 transition-all"
              >
                <i className="fas fa-file-invoice-dollar"></i> Generate Invoice
              </button>
            </div>
          </div>

          {/* Student Portal Content */}
          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full">
            {/* Student Tab: Home (MD profiles) */}
            {activeStudentTab === "home" && (
              <div className="space-y-12">
                <div className="text-center max-w-3xl mx-auto">
                  <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-xs font-bold uppercase tracking-wider rounded-full">
                    Dream Star Leaders
                  </span>
                  <h2 className="text-3xl font-extrabold text-slate-900 mt-3 mb-4">
                    Meet Our Managing Directors
                  </h2>
                  <p className="text-slate-600">
                    The driving forces leading our incredible squads toward endless success. Get inspired, work hard, and make your squad proud.
                  </p>
                </div>

                {/* MD Cards Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                  {Object.keys(teams).length === 0 ? (
                    <div className="col-span-full py-12 text-center text-slate-400">
                      No teams configured yet.
                    </div>
                  ) : (
                    Object.keys(teams).map((key) => {
                      const team = teams[key];
                      return (
                        <div
                          key={key}
                          className="bg-white rounded-3xl p-6 border border-slate-100 shadow-md shadow-slate-100/50 flex flex-col items-center text-center transition-all duration-300 hover:shadow-lg hover:-translate-y-1 relative overflow-hidden group"
                        >
                          <div className="absolute -right-6 -bottom-6 w-24 h-24 bg-indigo-50/60 rounded-full group-hover:scale-125 transition-transform duration-500"></div>
                          <div className="w-32 h-32 rounded-full p-1 border-2 border-indigo-600/25 mb-5 shadow-inner">
                            <img
                              src={team.mdImage}
                              alt={team.mdName}
                              className="w-full h-full object-cover rounded-full filter brightness-95 group-hover:brightness-100 transition-all"
                            />
                          </div>
                          <span className="px-3 py-1 bg-indigo-50 text-indigo-600 text-[11px] font-bold tracking-wider uppercase rounded-full mb-3">
                            {team.name}
                          </span>
                          <h4 className="text-base font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">
                            {team.mdName}
                          </h4>
                          <p className="text-xs text-slate-400 font-semibold mt-1 uppercase tracking-widest">
                            Managing Director
                          </p>
                          <div className="mt-4 pt-3 border-t border-slate-100 w-full text-left flex justify-between text-xs text-slate-500 font-semibold">
                            <button
                              onClick={() => viewTeamBreakdownDirectly(team.name)}
                              className="hover:text-indigo-600 cursor-pointer mx-auto"
                            >
                              <i className="fas fa-eye mr-1"></i> Access Squad Panel
                            </button>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* Student Tab: Registration Form */}
            {activeStudentTab === "register" && (
              <div>
                <div className="max-w-xl mx-auto bg-white p-8 rounded-2xl border border-slate-200/80 shadow-lg shadow-slate-100">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold text-slate-900 mb-2">Student Registration Form</h2>
                    <p className="text-sm text-slate-500">Select payment plan layout structure options.</p>
                  </div>

                  {/* Payment Type Buttons */}
                  <div className="grid grid-cols-2 gap-3 mb-6">
                    <button
                      type="button"
                      onClick={() => setRegPaymentType("Full Payment")}
                      className={`py-3 px-4 rounded-xl border-2 font-bold flex items-center justify-center gap-2 transition-all ${
                        regPaymentType === "Full Payment"
                          ? "border-indigo-600 bg-indigo-50/50 text-indigo-900"
                          : "border-slate-200 bg-white text-slate-600 font-semibold"
                      }`}
                    >
                      <i className="fas fa-money-check-dollar"></i> Full Payment
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegPaymentType("Booking")}
                      className={`py-3 px-4 rounded-xl border-2 font-bold flex items-center justify-center gap-2 transition-all ${
                        regPaymentType === "Booking"
                          ? "border-indigo-600 bg-indigo-50/50 text-indigo-900"
                          : "border-slate-200 bg-white text-slate-600 font-semibold"
                      }`}
                    >
                      <i className="fas fa-receipt"></i> Booking Slot
                    </button>
                  </div>

                  <form onSubmit={handleRegistration} className="space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                        Team / Squad Name
                      </label>
                      <select
                        value={regTeamSelect}
                        onChange={(e) => setRegTeamSelect(e.target.value)}
                        required
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all cursor-pointer"
                      >
                        <option value="" disabled>
                          Select a Team
                        </option>
                        {(Object.values(teams) as Team[]).map((team) => (
                          <option key={team.name} value={team.name}>
                            {team.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                          Seller ID
                        </label>
                        <input
                          type="text"
                          value={regSellerId}
                          onChange={(e) => setRegSellerId(e.target.value)}
                          required
                          placeholder="Enter Seller ID"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                          Batch Number
                        </label>
                        <select
                          value={regBatchSelect}
                          onChange={(e) => setRegBatchSelect(e.target.value)}
                          required
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all cursor-pointer"
                        >
                          <option value="" disabled>
                            Select Batch
                          </option>
                          {Object.values(batches).map((bName) => (
                            <option key={bName} value={bName}>
                              {bName}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                        Student Name
                      </label>
                      <input
                        type="text"
                        value={regStudentName}
                        onChange={(e) => setRegStudentName(e.target.value)}
                        required
                        placeholder="Enter Full Student Name"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                        Student ID
                      </label>
                      <input
                        type="text"
                        value={regStudentId}
                        onChange={(e) => setRegStudentId(e.target.value)}
                        required
                        placeholder="Enter Student ID"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all"
                      />
                    </div>

                    {regPaymentType === "Booking" && (
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                          Booking Amount (BDT)
                        </label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={regBookingAmount}
                          onChange={(e) => setRegBookingAmount(e.target.value.replace(/[^0-9]/g, ""))}
                          required
                          placeholder="e.g. 500"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 placeholder-slate-400 font-bold focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all"
                        />
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3.5 px-4 rounded-xl shadow-lg shadow-indigo-600/10 transition-all duration-200 transform active:scale-[0.98] mt-4"
                    >
                      <i className="fas fa-check-circle mr-2"></i>
                      {studentEditKey ? "Update Student Details" : "Register Student"}
                    </button>
                    {studentEditKey && (
                      <button
                        type="button"
                        onClick={resetRegForm}
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 px-4 rounded-xl transition-all mt-2"
                      >
                        Cancel Edit
                      </button>
                    )}
                  </form>
                </div>
              </div>
            )}

            {/* Student Tab: Databases */}
            {activeStudentTab === "database" && (
              <div>
                {!activeUnlockedSquad ? (
                  <div className="max-w-md mx-auto bg-white p-8 rounded-2xl border border-slate-200/80 shadow-lg shadow-slate-100/50 text-center">
                    <div className="w-14 h-14 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center mx-auto mb-4 border border-amber-100">
                      <i className="fas fa-lock text-xl"></i>
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-1">Squad Database Access</h3>
                    <p className="text-sm text-slate-500 mb-6">
                      Enter the respective squad's password to unlock and manage its data.
                    </p>

                    <div className="space-y-4">
                      <input
                        type="password"
                        value={squadPasswordInput}
                        onChange={(e) => setSquadPasswordInput(e.target.value)}
                        placeholder="••••••••"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-center text-slate-800 placeholder-slate-400 tracking-widest focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-600/5 transition-all"
                      />
                      <button
                        onClick={unlockSquadDatabase}
                        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-medium py-3 rounded-xl shadow-md transition-all"
                      >
                        Unlock Database
                      </button>
                    </div>
                    {squadPassError && (
                      <p className="text-rose-600 text-sm font-semibold mt-3">
                        <i className="fas fa-exclamation-circle mr-1"></i> Invalid Password! Try again.
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-white p-4 rounded-xl border border-slate-200 gap-4 shadow-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold text-lg border border-emerald-100">
                          <i className="fas fa-users-viewfinder"></i>
                        </div>
                        <div>
                          <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">
                            Access Unlocked
                          </span>
                          <h3 className="text-lg font-bold text-slate-900">{activeUnlockedSquad}</h3>
                        </div>
                      </div>
                      <button
                        onClick={lockSquadDatabase}
                        className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg border border-slate-200 transition-all flex items-center gap-1.5"
                      >
                        <i className="fas fa-lock"></i> Lock & Exit Squad
                      </button>
                    </div>

                    {/* Squad Stats Overview Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-xl border border-emerald-100">
                          <i className="fas fa-chart-line"></i>
                        </div>
                        <div>
                          <p className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                            Total Sales Generated
                          </p>
                          <h4 className="text-xl font-black text-slate-900">{unlockedSquadSales} BDT</h4>
                        </div>
                      </div>
                      <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-xl border border-rose-100">
                          <i className="fas fa-arrow-up-right-from-square"></i>
                        </div>
                        <div>
                          <p className="text-[11px] font-bold uppercase text-slate-400 tracking-wider">
                            Total Cash Withdrawn
                          </p>
                          <h4 className="text-xl font-black text-rose-600">{unlockedSquadWithdrawn} BDT</h4>
                        </div>
                      </div>
                    </div>

                    {/* Squad Table */}
                    <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs relative">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                              <th className="py-4 px-6">SL</th>
                              <th className="py-4 px-6">Seller ID</th>
                              <th className="py-4 px-6">Student Name</th>
                              <th className="py-4 px-6">Student ID</th>
                              <th className="py-4 px-6">Batch</th>
                              <th className="py-4 px-6">Payment Status</th>
                              <th className="py-4 px-6 text-center">Actions</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
                            {Object.keys(students)
                              .filter((k) => students[k].teamName === activeUnlockedSquad)
                              .map((key, index) => {
                                const s = students[key];
                                return (
                                  <tr key={key} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="py-4 px-6 text-slate-400 font-medium">{index + 1}</td>
                                    <td className="py-4 px-6 font-semibold text-slate-900">{s.sellerId}</td>
                                    <td className="py-4 px-6 font-bold text-indigo-600">{s.studentName}</td>
                                    <td className="py-4 px-6 font-mono text-xs text-slate-500">{s.studentId}</td>
                                    <td className="py-4 px-6">
                                      <span className="px-2.5 py-1 bg-slate-100 text-slate-600 text-xs font-semibold rounded-full">
                                        {s.batchNumber}
                                      </span>
                                    </td>
                                    <td className="py-4 px-6">
                                      {s.paymentType === "Booking" ? (
                                        <button
                                          onClick={() => convertToFullPayment(key)}
                                          className="px-3 py-1 bg-amber-100 hover:bg-emerald-600 hover:text-white text-amber-800 font-bold text-xs rounded-lg border border-amber-300 transition-all cursor-pointer shadow-xs animate-pulse text-left"
                                        >
                                          Booking: {s.bookingAmount} BDT
                                          <span className="block text-[10px] underline font-medium">Click for Full</span>
                                        </button>
                                      ) : (
                                        <span className="px-3 py-1 bg-emerald-100 text-emerald-800 font-black text-xs rounded-lg border border-emerald-300 flex items-center gap-1 w-fit">
                                          <i className="fas fa-circle-check"></i> Full Payment
                                        </span>
                                      )}
                                    </td>
                                    <td className="py-4 px-6 text-center">
                                      <div className="flex items-center justify-center gap-2">
                                        <button
                                          onClick={() => editStudentRecord(key)}
                                          className="p-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg transition-all text-xs"
                                        >
                                          <i className="fas fa-edit"></i>
                                        </button>
                                        <button
                                          onClick={() => deleteStudentRecord(key)}
                                          className="p-2 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg transition-all text-xs"
                                        >
                                          <i className="fas fa-trash"></i>
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })}
                          </tbody>
                        </table>
                      </div>
                      {Object.keys(students).filter((k) => students[k].teamName === activeUnlockedSquad).length === 0 && (
                        <div className="p-12 text-center text-slate-400">
                          <i className="fas fa-folder-open text-3xl mb-3 block text-slate-300"></i> No students registered yet.
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}
          </main>
        </div>
      )}

      {/* PORTAL 2: ADMIN PORTAL */}
      {activePortal === "admin-portal" && (
        <div className="flex-grow flex flex-col">
          <div className="bg-white border-b border-slate-100 py-3 shadow-xs">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center sm:justify-start gap-4 flex-wrap">
              <button
                onClick={() => setActiveAdminTab("team-config")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeAdminTab === "team-config"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-users-cog mr-1.5 text-indigo-600"></i>
                Squads & MDs
              </button>
              <button
                onClick={() => setActiveAdminTab("batch-config")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeAdminTab === "batch-config"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-graduation-cap mr-1.5"></i>
                Batch Config
              </button>
              <button
                onClick={() => setActiveAdminTab("master-db")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeAdminTab === "master-db"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-folder-tree mr-1.5"></i>
                Master DB (Filters)
              </button>
              <button
                onClick={() => setActiveAdminTab("financial-insights")}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  activeAdminTab === "financial-insights"
                    ? "bg-slate-100 text-slate-800"
                    : "text-slate-600 hover:text-slate-800"
                }`}
              >
                <i className="fas fa-chart-line mr-1.5"></i>
                Amount Per Batch
              </button>
            </div>
          </div>

          <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-grow w-full">
            {/* Admin Tab: Squads & MDs */}
            {activeAdminTab === "team-config" && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs h-fit">
                    <div className="mb-5">
                      <h3 className="text-lg font-bold text-slate-900">
                        {editTeamKey ? "Edit Configured Team Details" : "Add New Team / Squad"}
                      </h3>
                      <p className="text-xs text-slate-500 mt-1">
                        Configure squad credentials and assign Managing Directors.
                      </p>
                    </div>

                    <form onSubmit={handleTeamConfigSubmit} className="space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                          Team Name
                        </label>
                        <input
                          type="text"
                          value={adminTeamName}
                          onChange={(e) => setAdminTeamName(e.target.value)}
                          required
                          placeholder="e.g. Winner Squad"
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-slate-800 focus:outline-none focus:border-indigo-600 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                          Password
                        </label>
                        <input
                          type="text"
                          value={adminTeamPassword}
                          onChange={(e) => setAdminTeamPassword(e.target.value)}
                          required
                          placeholder="Access password"
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-slate-800 focus:outline-none focus:border-indigo-600 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                          MD Name
                        </label>
                        <input
                          type="text"
                          value={adminTeamMdName}
                          onChange={(e) => setAdminTeamMdName(e.target.value)}
                          required
                          placeholder="Managing Director's Name"
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-slate-800 focus:outline-none focus:border-indigo-600 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                          MD Photo URL
                        </label>
                        <input
                          type="url"
                          value={adminTeamMdImage}
                          onChange={(e) => setAdminTeamMdImage(e.target.value)}
                          required
                          placeholder="https://domain.com/photo.jpg"
                          className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-slate-800 focus:outline-none focus:border-indigo-600 transition-all"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2.5 rounded-lg text-sm transition-all shadow-xs"
                      >
                        Save Team Configuration
                      </button>
                      {editTeamKey && (
                        <button
                          type="button"
                          onClick={resetAdminTeamForm}
                          className="w-full bg-slate-100 hover:bg-slate-200 text-slate-600 py-2 rounded-lg text-sm transition-all mt-2"
                        >
                          Cancel Edit
                        </button>
                      )}
                    </form>
                  </div>

                  <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col">
                    <div className="p-5 border-b border-slate-100 flex justify-between items-center">
                      <div>
                        <h3 className="text-lg font-bold text-slate-900">Active Squads & MD Profiles</h3>
                        <p className="text-xs text-slate-500">Live operational teams and control configs.</p>
                      </div>
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-2">
                        <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Course Fee:</label>
                        <input
                          type="text"
                          inputMode="numeric"
                          value={courseFee}
                          onChange={(e) => updateGlobalCourseFee(e.target.value.replace(/[^0-9]/g, ""))}
                          placeholder="Fee"
                          className="w-24 px-2 py-1 bg-white border border-slate-300 rounded text-sm font-bold text-slate-800"
                        />
                      </div>
                    </div>

                    <div className="overflow-x-auto flex-grow">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-slate-50 border-b border-slate-100 text-xs font-bold text-slate-500 uppercase tracking-wider">
                            <th className="py-3 px-5">MD Profile</th>
                            <th className="py-3 px-5">Team / Squad</th>
                            <th className="py-3 px-5">Squad Password</th>
                            <th className="py-3 px-5 text-center">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 text-sm">
                          {Object.keys(teams).map((key) => {
                            const team = teams[key];
                            return (
                              <tr key={key} className="hover:bg-slate-50/50 transition-colors">
                                <td className="py-3 px-5 flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full border border-slate-200 overflow-hidden shrink-0">
                                    <img src={team.mdImage} className="w-full h-full object-cover" alt={team.mdName} />
                                  </div>
                                  <div>
                                    <p className="font-semibold text-slate-800">{team.mdName}</p>
                                    <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">
                                      MD Profile
                                    </p>
                                  </div>
                                </td>
                                <td className="py-3 px-5 font-bold text-indigo-600">{team.name}</td>
                                <td className="py-3 px-5 font-mono text-slate-500 font-semibold">{team.password}</td>
                                <td className="py-3 px-5 text-center">
                                  <div className="flex items-center justify-center gap-2">
                                    <button
                                      onClick={() => editTeamConfig(key)}
                                      className="p-1.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg transition-all text-xs"
                                      title="Edit"
                                    >
                                      <i className="fas fa-edit"></i>
                                    </button>
                                    <button
                                      onClick={() => resetTeamWithdrawals(team.name)}
                                      className="px-2 py-1 bg-amber-50 text-amber-700 hover:bg-amber-600 hover:text-white text-xs font-bold rounded-lg border border-amber-200 transition-all"
                                      title="Reset Withdrawn Amount"
                                    >
                                      <i className="fas fa-rotate-left mr-1"></i>Reset Amount
                                    </button>
                                    <button
                                      onClick={() => deleteTeamConfig(key)}
                                      className="p-1.5 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg transition-all text-xs"
                                      title="Delete"
                                    >
                                      <i className="fas fa-trash"></i>
                                    </button>
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Admin Tab: Batch Configuration */}
            {activeAdminTab === "batch-config" && (
              <div className="max-w-2xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs h-fit md:col-span-1">
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Configure Batch</h3>
                  <p className="text-xs text-slate-500 mb-4">Introduce operational batch identifiers.</p>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1.5">
                        Batch Name/ID
                      </label>
                      <input
                        type="text"
                        value={adminBatchInput}
                        onChange={(e) => setAdminBatchInput(e.target.value)}
                        placeholder="e.g. Batch 01"
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-slate-800 focus:outline-none focus:border-indigo-600 transition-all text-sm"
                      />
                    </div>
                    <button
                      onClick={addBatchConfig}
                      className="w-full bg-slate-900 hover:bg-slate-800 text-white font-medium py-2 rounded-lg text-sm transition-all shadow-xs"
                    >
                      Add New Batch
                    </button>
                  </div>
                </div>

                <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 md:col-span-2">
                  <h3 className="text-lg font-bold text-slate-900 mb-1">Active Batches</h3>
                  <p className="text-xs text-slate-500 mb-5">Current running student batches dynamically rendering on form.</p>

                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {Object.keys(batches).map((key) => {
                      const batchName = batches[key];
                      return (
                        <div
                          key={key}
                          className="flex items-center justify-between bg-slate-50 border border-slate-200 py-2 px-3 rounded-xl"
                        >
                          <span className="font-bold text-slate-800 text-xs tracking-wide">{batchName}</span>
                          <button
                            onClick={() => deleteBatchConfig(key)}
                            className="text-rose-500 hover:text-rose-700 p-1 text-xs"
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        </div>
                      );
                    })}
                  </div>
                  {Object.keys(batches).length === 0 && (
                    <div className="text-center py-8 text-slate-400">
                      <i className="fas fa-graduation-cap text-3xl mb-2 text-slate-300 block"></i> No batches configured yet.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Admin Tab: Master DB with Filters */}
            {activeAdminTab === "master-db" && (
              <div className="space-y-6">
                <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-4 items-center justify-between">
                  <div className="flex items-center gap-3 w-full md:w-auto">
                    <div className="w-10 h-10 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
                      <i className="fas fa-filter"></i>
                    </div>
                    <div>
                      <h3 className="font-bold text-slate-950">Master Database Filters</h3>
                      <p className="text-xs text-slate-500">Filter options for registrations & bookings.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-3 w-full md:w-auto md:flex">
                    <select
                      value={filterType}
                      onChange={(e) => setFilterType(e.target.value)}
                      className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm text-slate-700 font-medium focus:outline-none focus:border-indigo-600 transition-all cursor-pointer"
                    >
                      <option value="all">All Status</option>
                      <option value="Full Payment">Full Payment</option>
                      <option value="Booking">Booking Slot</option>
                    </select>

                    <select
                      value={filterTeam}
                      onChange={(e) => setFilterTeam(e.target.value)}
                      className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm text-slate-700 font-medium focus:outline-none focus:border-indigo-600 transition-all cursor-pointer"
                    >
                      <option value="all">All Squads</option>
                      {(Object.values(teams) as Team[]).map((team) => (
                        <option key={team.name} value={team.name}>
                          {team.name}
                        </option>
                      ))}
                    </select>

                    <select
                      value={filterBatch}
                      onChange={(e) => setFilterBatch(e.target.value)}
                      className="bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm text-slate-700 font-medium focus:outline-none focus:border-indigo-600 transition-all cursor-pointer"
                    >
                      <option value="all">All Batches</option>
                      {Object.values(batches).map((bName) => (
                        <option key={bName} value={bName}>
                          {bName}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-xs font-bold text-slate-500 uppercase tracking-wider">
                          <th className="py-4 px-6">SL</th>
                          <th className="py-4 px-6">Team Name</th>
                          <th className="py-4 px-6">Seller ID</th>
                          <th className="py-4 px-6">Student Name</th>
                          <th className="py-4 px-6">Student ID</th>
                          <th className="py-4 px-6">Batch</th>
                          <th className="py-4 px-6">Status Info</th>
                          <th className="py-4 px-6 text-center">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
                        {filteredMasterStudents.map((key, idx) => {
                          const student = students[key];
                          return (
                            <tr key={key} className="hover:bg-slate-50/50 transition-colors">
                              <td className="py-4 px-6 text-slate-400 font-medium">{idx + 1}</td>
                              <td className="py-4 px-6">
                                <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 text-xs font-bold uppercase rounded-full">
                                  {student.teamName}
                                </span>
                              </td>
                              <td className="py-4 px-6 font-semibold text-slate-900">{student.sellerId}</td>
                              <td className="py-4 px-6 font-bold text-slate-800">{student.studentName}</td>
                              <td className="py-4 px-6 font-mono text-xs text-slate-500">{student.studentId}</td>
                              <td className="py-4 px-6 font-semibold text-slate-600">{student.batchNumber}</td>
                              <td className="py-4 px-6">
                                {student.paymentType === "Booking" ? (
                                  <span className="px-2 py-0.5 bg-amber-50 text-amber-700 font-bold border border-amber-200 rounded text-xs">
                                    Booking ({student.bookingAmount})
                                  </span>
                                ) : (
                                  <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold border border-emerald-200 rounded text-xs">
                                    Full Payment
                                  </span>
                                )}
                              </td>
                              <td className="py-4 px-6 text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <button
                                    onClick={() => editStudentRecord(key)}
                                    className="p-2 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-lg transition-all text-xs"
                                  >
                                    <i className="fas fa-edit"></i>
                                  </button>
                                  <button
                                    onClick={() => deleteStudentRecord(key)}
                                    className="p-2 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-lg transition-all text-xs"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                  {filteredMasterStudents.length === 0 && (
                    <div className="p-12 text-center text-slate-400">
                      <i className="fas fa-database text-3xl mb-3 block text-slate-300"></i> No records found.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Admin Tab: Financial Insights */}
            {activeAdminTab === "financial-insights" && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-green-50 text-green-600 flex items-center justify-center text-xl">
                      <i className="fas fa-wallet"></i>
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase text-slate-400 tracking-wider">System Total Sales</p>
                      <h3 className="text-2xl font-black text-slate-900">{grandTotalSales} BDT</h3>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center text-xl">
                      <i className="fas fa-check-double"></i>
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase text-slate-400 tracking-wider">Full Payments Total</p>
                      <h3 className="text-2xl font-black text-slate-900">{totalFullPaymentAmt} BDT</h3>
                    </div>
                  </div>
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center text-xl">
                      <i className="fas fa-book-bookmark"></i>
                    </div>
                    <div>
                      <p className="text-xs font-bold uppercase text-slate-400 tracking-wider">Bookings Total Collection</p>
                      <h3 className="text-2xl font-black text-slate-900">{totalBookingAmt} BDT</h3>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
                  <h3 className="text-lg font-bold text-slate-900 mb-2">Batch Wise Performance Summary</h3>
                  <p className="text-xs text-slate-400 mb-6">Realtime aggregate matrix statistics sorted per active batch configuration.</p>
                  
                  <div className="space-y-6">
                    {Object.keys(batchAnalytics).map((bName) => {
                      const data = batchAnalytics[bName];
                      return (
                        <div key={bName} className="p-5 border border-slate-200 bg-slate-50/50 rounded-xl space-y-4">
                          <div className="flex flex-col sm:flex-row justify-between sm:items-center border-b border-slate-200 pb-2 gap-2">
                            <div>
                              <h4 className="font-black text-slate-900 text-base flex items-center gap-2">
                                <i className="fas fa-graduation-cap text-indigo-600"></i> {bName}
                              </h4>
                              <p className="text-xs text-slate-400 font-semibold">
                                Full Payments: {data.fullPaymentCount} | Bookings: {data.bookingCount}
                              </p>
                            </div>
                            <div className="text-right">
                              <span className="text-xs font-bold text-slate-400 block uppercase">Total Batch Revenue</span>
                              <span className="text-lg font-black text-green-600">{data.totalRevenue} BDT</span>
                            </div>
                          </div>
                          <div>
                            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                              Team Wise Sales for this Batch:
                            </p>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
                              {Object.keys(data.teamContributions).map((tName) => (
                                <div key={tName} className="flex justify-between items-center text-xs bg-white p-2 rounded border border-slate-100">
                                  <span className="font-bold text-slate-700">{tName}</span>
                                  <span className="font-black text-indigo-600">{data.teamContributions[tName]} BDT</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}
          </main>
        </div>
      )}

      {/* DYNAMIC INVOICE GENERATOR OVERLAY MODAL */}
      {isInvoiceModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl p-6 max-w-xl w-full animate-pop-in flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                  <i className="fas fa-file-invoice-dollar"></i>
                </div>
                <h3 className="text-lg font-bold text-slate-900">Create Team Bill Invoice</h3>
              </div>
              <button
                onClick={() => setIsInvoiceModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-lg p-1"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="flex-grow overflow-y-auto pr-1 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Select Team
                </label>
                <select
                  value={invoiceTeamSelect}
                  onChange={(e) => setInvoiceTeamSelect(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-slate-800 font-semibold focus:outline-none focus:border-emerald-600 cursor-pointer"
                >
                  <option value="" disabled>
                    Select a Squad
                  </option>
                  {(Object.values(teams) as Team[]).map((team) => (
                    <option key={team.name} value={team.name}>
                      {team.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    Sellers Amount breakdown
                  </span>
                  <button
                    type="button"
                    onClick={addInvoiceItemRow}
                    className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-lg transition-all flex items-center gap-1"
                  >
                    <i className="fas fa-plus"></i> Add Multi-Seller
                  </button>
                </div>

                <div className="space-y-2.5">
                  {invoiceRows.map((row) => (
                    <div
                      key={row.id}
                      className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200/60 animate-pop-in"
                    >
                      <div className="flex-grow grid grid-cols-2 gap-2">
                        <input
                          type="text"
                          value={row.sellerId}
                          onChange={(e) => {
                            const val = e.target.value;
                            setInvoiceRows((prev) =>
                              prev.map((r) => (r.id === row.id ? { ...r, sellerId: val } : r))
                            );
                          }}
                          placeholder="Seller ID"
                          className="w-full bg-white border border-slate-200 px-3 py-1.5 text-sm rounded-lg text-slate-800 focus:outline-none focus:border-emerald-500"
                          required
                        />
                        <input
                          type="text"
                          inputMode="numeric"
                          value={row.amount}
                          onChange={(e) => {
                            const val = e.target.value.replace(/[^0-9]/g, "");
                            setInvoiceRows((prev) =>
                              prev.map((r) => (r.id === row.id ? { ...r, amount: val } : r))
                            );
                          }}
                          placeholder="Amount (BDT)"
                          className="w-full bg-white border border-slate-200 px-3 py-1.5 text-sm font-bold rounded-lg text-slate-800 focus:outline-none focus:border-emerald-600"
                          required
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeInvoiceItemRow(row.id)}
                        className="text-rose-500 hover:text-rose-700 p-1.5 text-sm"
                      >
                        <i className="fas fa-minus-circle"></i>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-4 mt-4 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 block uppercase">Total Bill Gross</span>
                <span className="text-2xl font-black text-emerald-600">{calculateInvoiceGross()} BDT</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setInvoiceRows([{ id: "inv-row-1", sellerId: "", amount: "" }]);
                  }}
                  className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-700 text-sm font-semibold rounded-xl transition-all"
                >
                  <i className="fas fa-rotate-left mr-1"></i>Reset
                </button>
                <button
                  onClick={() => setIsInvoiceModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold rounded-xl transition-all"
                >
                  Discard
                </button>
                <button
                  onClick={submitInvoiceBill}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-bold rounded-xl shadow-md transition-all"
                >
                  Withdraw & Get Receipt
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* DYNAMIC MONEY RECEIPT VIEW MODAL (PNG DOWNLOADABLE) */}
      {isReceiptModalOpen && receiptData && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-md flex flex-col items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="max-w-md w-full bg-white rounded-2xl shadow-2xl overflow-hidden animate-pop-in border border-slate-100 flex flex-col my-auto">
            {/* Printable/Convertible Receipt Area */}
            <div ref={receiptCaptureRef} className="bg-white p-8 text-slate-800 relative space-y-6">
              <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-indigo-600"></div>

              <div className="flex justify-between items-start pt-2">
                <div>
                  <div className="flex items-center gap-1.5 text-slate-900 font-black text-base tracking-tight">
                    <i className="fas fa-star text-amber-400"></i> DREAM STAR COMMUNITY
                  </div>
                  <p className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">
                    Official Payment Statement
                  </p>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-black text-[10px] tracking-wide uppercase">
                    PAID / DEPOSITED
                  </span>
                </div>
              </div>

              <div className="border-y border-dashed border-slate-200 py-3 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <p className="text-slate-400 font-medium">Receipt No:</p>
                  <p className="font-mono font-bold text-slate-800">{receiptData.id}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-400 font-medium">Issue Date:</p>
                  <p className="font-semibold text-slate-700">{receiptData.date}</p>
                </div>
              </div>

              <div className="space-y-1.5 text-xs">
                <p className="text-slate-400 font-medium uppercase tracking-wider text-[10px]">
                  Squad Specification
                </p>
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center">
                  <div>
                    <p className="font-extrabold text-slate-900 text-sm">{receiptData.team}</p>
                    <p className="text-[10px] text-slate-500 font-medium">MD Management Statement</p>
                  </div>
                  <i className="fas fa-shield-halved text-indigo-500/30 text-xl"></i>
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-slate-400 font-medium uppercase tracking-wider text-[10px]">
                  Sellers Breakdown Logs
                </p>
                <div className="border border-slate-100 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-50 font-bold text-slate-500 border-b border-slate-100">
                        <th className="p-2.5">Seller Account ID</th>
                        <th className="p-2.5 text-right">Amount Withdrawn</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                      {receiptData.items.map((item, i) => (
                        <tr key={i}>
                          <td className="p-2.5 font-mono text-slate-900">{item.sellerId}</td>
                          <td className="p-2.5 text-right font-black text-slate-950">{item.amount} BDT</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center border-t border-slate-200">
                <div>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    Gross Statement Net
                  </p>
                  <p className="text-[9px] text-slate-400 font-medium italic">Authorized via System Ledger Token</p>
                </div>
                <div className="text-right">
                  <h2 className="text-2xl font-black text-slate-950 tracking-tight">{receiptData.gross} BDT</h2>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="bg-slate-50 p-4 border-t border-slate-100 grid grid-cols-2 gap-3">
              <button
                onClick={() => setIsReceiptModalOpen(false)}
                className="py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-xl transition-all"
              >
                Close View
              </button>
              <button
                onClick={downloadReceiptAsPNG}
                className="py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl shadow-md transition-all flex items-center justify-center gap-1.5"
              >
                <i className="fas fa-download"></i> Download PNG Receipt
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SUCCESS ANIMATION OVERLAY */}
      {isSuccessModalOpen && successDetails && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-8 max-w-md w-full border border-slate-100 shadow-2xl text-center animate-pop-in relative overflow-hidden">
            <div className="w-20 h-20 bg-emerald-50 text-emerald-500 border border-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-md animate-bounce">
              <i className="fas fa-check text-4xl"></i>
            </div>
            <span
              className={`px-3.5 py-1 text-xs font-bold uppercase tracking-widest rounded-full ${
                successDetails.type === "Booking"
                  ? "bg-amber-50 text-amber-700"
                  : "bg-emerald-50 text-emerald-700"
              }`}
            >
              {successDetails.type === "Booking" ? "Slot Booking Registered!" : "Full Payment Success!"}
            </span>
            <h3 className="text-2xl font-extrabold text-slate-950 mt-4 mb-2">
              {successDetails.type === "Booking" ? "Slot Booking Registered!" : "Successful!"}
            </h3>

            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 my-5 text-slate-600 text-sm text-left space-y-2">
              <p>
                🙋‍♂️ <span className="font-semibold text-slate-900">Student:</span>{" "}
                <span className="font-medium text-slate-700">{successDetails.studentName}</span>
              </p>
              <p>
                🛡️ <span className="font-semibold text-slate-900">Registered to:</span>{" "}
                <span className="font-bold text-indigo-600">{successDetails.teamName}</span>
              </p>
              <p>
                🔥 <span className="font-semibold text-slate-900">Managing Director:</span>{" "}
                <span className="font-bold text-indigo-600">{successDetails.mdName}</span>
              </p>
            </div>
            <button
              onClick={() => {
                setIsSuccessModalOpen(false);
                setActiveStudentTab("home");
              }}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3.5 px-4 rounded-xl shadow-md transition-all"
            >
              Continue
            </button>
          </div>
        </div>
      )}

      {/* ADMIN AUTHENTICATION MODAL */}
      {isAdminAuthModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-slate-100 shadow-2xl animate-pop-in relative overflow-hidden">
            <div className="flex justify-between items-center mb-5">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-slate-900 text-white rounded-2xl flex items-center justify-center text-xl shadow-md">
                  <i className="fas fa-user-shield"></i>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900">Admin Console Access</h3>
                  <p className="text-xs text-slate-500">Security authentication required</p>
                </div>
              </div>
              <button
                onClick={() => setIsAdminAuthModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-2 rounded-xl text-lg transition-all"
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <form onSubmit={submitAdminAuth} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-2">
                  Admin Console Password
                </label>
                <input
                  type="password"
                  value={adminAuthPasswordInput}
                  onChange={(e) => {
                    setAdminAuthPasswordInput(e.target.value);
                    setAdminAuthError("");
                  }}
                  placeholder="Enter admin password (admin123)"
                  autoFocus
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 font-semibold focus:outline-none focus:border-slate-900 transition-all text-sm"
                />
              </div>

              {adminAuthError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                  <i className="fas fa-circle-exclamation text-rose-500"></i>
                  {adminAuthError}
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/60">
                <span>Default Password:</span>
                <button
                  type="button"
                  onClick={() => {
                    setAdminAuthPasswordInput("admin123");
                    setAdminAuthError("");
                  }}
                  className="px-2.5 py-1 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 font-bold rounded-lg transition-all text-xs"
                >
                  Fill "admin123"
                </button>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdminAuthModalOpen(false)}
                  className="w-1/3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-3 rounded-xl text-sm transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-2/3 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <i className="fas fa-unlock"></i> Unlock Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400 font-medium">
        <p>© 2026 Dream Star MD Management System. All database assets hosted securely.</p>
      </footer>

      {/* NEW: AI INTELLIGENCE ASSISTANT AT THE BOTTOM ("niche ai thakbe") */}
      <AiAssistant databaseState={databaseStateForAi} />
    </div>
  );
}
