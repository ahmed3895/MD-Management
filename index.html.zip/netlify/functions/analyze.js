const { GoogleGenAI } = require("@google/genai");

exports.handler = async function (event, context) {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method Not Allowed" };
  }

  try {
    const { question, databaseState } = JSON.parse(event.body || "{}");
    const apiKey = process.env.GEMINI_API_KEY || process.env.VITE_GEMINI_API_KEY || "AQ.Ab8RN6LY2y2yC8fQn6AKr3501TdmXG2K0jFqsZNFXqL-fcgtkQ";

    if (!apiKey) {
      return {
        statusCode: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "NO_API_KEY" })
      };
    }

    const ai = new GoogleGenAI({ apiKey });
    const systemPrompt = `You are Dream Star MD Management System's official AI Analytics Assistant.
You have real-time access to the complete Firebase database state of the system provided below in JSON format.
Your goal is to answer questions about student registrations, batch performance, seller outputs, team/MD financial analytics, withdrawals, and course fee collections accurately.

DATABASE STATE SUMMARY:
${JSON.stringify(databaseState, null, 2)}

INSTRUCTIONS:
1. Answer accurately based ONLY on the provided live database state.
2. If asked in Bengali (Bangla) or Bangla-English script (e.g., "koto taka", "koto jon student", "top squad kon ta"), reply in Bengali with clear formatting (bold numbers, lists, bullet points). If asked in English, reply in English.
3. Include specific numbers (BDT amounts, student counts, seller totals) whenever applicable.
4. Keep answers friendly, professional, structured, and easy to read.`;

    let responseText = "";
    try {
      const res = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `${systemPrompt}\n\nUSER QUESTION: ${question}` }],
          },
        ],
      });
      responseText = res.text || "";
    } catch (mErr) {
      const res = await ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: [
          {
            role: "user",
            parts: [{ text: `${systemPrompt}\n\nUSER QUESTION: ${question}` }],
          },
        ],
      });
      responseText = res.text || "";
    }

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answer: responseText || "No response generated." })
    };
  } catch (err) {
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message || "Failed to analyze" })
    };
  }
};
